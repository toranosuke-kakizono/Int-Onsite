

// 文章を編集しよう ⭐️

if(welcomeText) {
  if(typeof welcomeText !== "string") {
    console.error("welcomeText は文字列にしましょう！")
  } else {
    const siteDescriptionTag = document.querySelector("#js-site-description");
      siteDescriptionTag.innerText = welcomeText;
  }
}


// お知らせの幅を変更しよう ⭐️

if(newsWidth) {
  if(typeof newsWidth !== "string" 
    && typeof newsWidth !== "undefined") {
      console.error("newsWidth は文字列型になるはずです！ 問題文を見返してみましょう👀")
    }

  const newsSection = document.querySelector("#js-news-outer-section");
  newsSection.style.width = newsWidth;
}

/* 商品一覧の枠やお知らせの角を丸くしよう ⭐️
→ display-items.js, display-news.js */

