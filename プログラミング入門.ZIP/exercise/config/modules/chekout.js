window.onload = (e) => {
  const itemsInCart = JSON.parse(localStorage.getItem("shoppingCart"))
  const container = document.getElementById("js-item-confirmation-container");
  
  if(Object.keys(itemsInCart).length === 0) {
    const pTag = document.createElement("p");
    pTag.innerText = "カートに商品がありません";
    pTag.style.textAlign = "center";
    container.appendChild(pTag);
    
    const checkoutButton = document.querySelector("#js-checkout-button");
    checkoutButton.style.display = "none";
  }

  for(itemName in itemsInCart) {

    // 生徒が途中でアイテムを変更していた場合、isValidItem は途中にならない
      // 想定ケース: 生徒がカートにデフォルトのアイテムを入れた。その後、問題の指示に従ってアイテムのタイトルを変更した。するとカートにはデフォルトアイテムが残っているが商品のリストからは既に削除されているためエラーが生じる
    let isValidItem = false;
    for(const shopItem of shopItems) {
      if(shopItem.name === itemName) {
        isValidItem = true
        break;
      };
    }

    if(isValidItem) {
  
      const section = document.createElement("section");
      section.className = "itemInCart";

      // // テーマカラーを変更しよう ⭐️⭐️
      // section.style.backgroundColor = subThemeColor;

      section.classList.add(`${themeColor}-sub`)
      
      const itemNameTag = document.createElement("h3");
      itemNameTag.innerText = itemName;
      section.appendChild(itemNameTag);
  
      const count = itemsInCart[itemName];
      const itemCountTag = document.createElement("p");
      itemCountTag.innerText = count;
      section.appendChild(itemCountTag);
  
      const priceTag = document.createElement("p");

      const pricePerItem = shopItems.filter(item => item.name === itemName)[0].price;
      const amount = itemsInCart[itemName];
      const price = pricePerItem * amount;

      const priceOfItem = `¥ ${price.toLocaleString()}`;
      priceTag.innerText = priceOfItem;
      section.appendChild(priceTag);
      
      container.appendChild(section);
    }
  } 
}

const checkoutButton = document.querySelector("#js-checkout-button");

// ボタンの色を変更しよう ⭐️⭐️
checkoutButton.classList.add(`${themeColor}-button-strong`);

// カーソルの種類を変更しよう ⭐️⭐️
if(buttonCursor) checkoutButton.style.cursor = buttonCursor;

checkoutButton.addEventListener("click", e => {
  localStorage.removeItem("shoppingCart");
  window.alert("ご購入ありがとうございました！");
  location.href= "../index.html";
})