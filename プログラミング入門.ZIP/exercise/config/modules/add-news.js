const addArticle = e => {
  e.preventDefault();
  const title = e.target[0].value;
  if(!title) {
    console.error("タイトルを入力してください");
    return
  }

  const articles = JSON.parse(localStorage.getItem("articles"));

  if(today && typeof today !== "object") {
    console.error("JavaScript で「現在」を表す方法が少し違うようです👀")
  }

  articles.unshift({
    title: title,
    date: today ? today.toLocaleDateString('ja-JP') : new Date("1991/03/10").toLocaleDateString('ja-JP'),
  });

  localStorage.setItem("articles", JSON.stringify(articles));

  location.href = "../index.html";
}

const form = document.querySelector("#js-add-news-form");
form.addEventListener("submit", addArticle);

const deleteArticlesButton = document.querySelector("#js-delete-news-button");
deleteArticlesButton.addEventListener("click", (e) => {
  localStorage.removeItem("articles");
  location.href = "../index.html";
})

const buttons = document.querySelectorAll("button");
buttons.forEach(button => {
  button.classList.add(`${themeColor}-button-strong`)
})

// カーソルの種類を変更しよう ⭐️⭐️
if(buttonCursor) {
  buttons.forEach(button => {
    button.style.cursor = buttonCursor;
  })
}