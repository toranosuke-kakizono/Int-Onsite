if(!localStorage.getItem("shoppingCart")) {
  localStorage.setItem("shoppingCart", JSON.stringify({}));
}
