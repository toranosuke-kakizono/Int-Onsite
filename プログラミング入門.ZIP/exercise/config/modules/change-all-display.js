// ショップのタイトルを変更しよう ⭐️

if(title) {

  if(typeof title !== "string") {
    console.error("タイトルは文字列にしましょう！");
  } else {
    const titleTag = document.querySelector("title");
    titleTag.innerText = title;
  
    const h1Tag = document.querySelector("#js-h1");
    h1Tag.innerText = title;
  
    const footerText = document.querySelector("#js-footer-text");
    footerText.innerText = `©︎ ${new Date().getFullYear()} ${title}`;
  }

}

/* 

商品のタイトルを変更しよう ⭐️
商品の個数と値段を変更しよう ⭐️

*/

const shopItems = [
  {
    name: itemName1 ? itemName1 : "レーズンバターサンド",
    amount: itemAmount1 ? itemAmount1 : "10個",
    price: itemPrice1 ? itemPrice1 : 1000,
    image: itemImagePath1 
      ? itemImagePath1 
      : "./images/buttersand.png",
  },
  {
    name: itemName2 ? itemName2 : "こだわりチョコレート",
    amount: itemAmount2 ? itemAmount2 : "10個",
    price: itemPrice2 ? itemPrice2 : 1000,
    image: itemImagePath2 
      ? itemImagePath2 
      : "./images/chocolatiere.png",
  },
  {
    name: itemName3 ? itemName3 : "フォンダンショコラ",
    amount: itemAmount3 ? itemAmount3 : "10個",
    price: itemPrice3 ? itemPrice3 : 1000,
    image: itemImagePath3 
      ? itemImagePath3 
      : "./images/fondant_au_chocolat.png",
  },
  {
    name: itemName4 ? itemName4 : "最近話題のいちごあめ",
    amount: itemAmount4 ? itemAmount4 : "10個",
    price: itemPrice4 ? itemPrice4 : 1000,
    image: itemImagePath4 
      ? itemImagePath4 
      : "./images/ichigo-ame.png",
  },
  {
    name: itemName5 ? itemName5 : "ごほうびいちごサンド",
    amount: itemAmount5 ? itemAmount5 : "10個",
    price: itemPrice5 ? itemPrice5 : 1000,
    image: itemImagePath5 
      ? itemImagePath5 
      : "./images/strawberry_sandwich.png",
  },
];

// テーマカラーを変更しよう ⭐️⭐️
// items → display-items.js
// news → display-news.js

const colors = [ "orange", "red", "yellow", "blue", "green", "purple", "black", "pink", "paleBlue", "brown" ];

if(typeof themeColor !== "string") {
  console.error("themeColor は文字列にしましょう！");
  } else if (!colors.includes(themeColor)) {
  console.error("その色には対応していません🙏");
} else {
  const header = document.querySelector("header");
  const headerA = document.querySelector("#js-h1")
  const shoppingCartIcon = document.querySelector("#js-shopping-cart-icon")
  const footer = document.querySelector("footer");
  const footerA = document.querySelector("#js-footer-text-a");
  
  header.classList.add(`${themeColor}-main`);
  footer.classList.add(`${themeColor}-main`);
  
  headerA.classList.add(`${themeColor}-text`);
  shoppingCartIcon.classList.add(`${themeColor}-text`);
  footerA.classList.add(`${themeColor}-text`);
}


// カーソルの種類を変更しよう ⭐️⭐️

const shoppingCartIconI = document.querySelector(".fa-cart-shopping");
if(buttonCursor) shoppingCartIconI.style.cursor = buttonCursor;