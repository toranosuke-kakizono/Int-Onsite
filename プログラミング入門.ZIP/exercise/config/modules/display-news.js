if(!localStorage.getItem("articles")) {
  const articles = [
    {
      title: "ショップを開設しました",
      date: new Date().toLocaleDateString('ja-JP'),
    },
  ]
  localStorage.setItem("articles", JSON.stringify(articles));
}

const articles = JSON.parse(localStorage.getItem("articles"))

const articleContainer = document.getElementById("js-news-container");

articles.forEach(article => {
  const articleTag = document.createElement("article");
  
  if(radius) {
    if(typeof radius !== "string" 
      && typeof radius !== "undefined") {
        console.error("radius は文字列型になるはずです！ 問題文を見返してみましょう👀")
        return;
      }

    articleTag.style.borderRadius = radius;
  }

  // if(themeColor) articleTag.style.backgroundColor = subThemeColor;
  articleTag.classList.add(`${themeColor}-sub`);

  const dateTag = document.createElement("p");
  dateTag.innerText = article.date;
  articleTag.appendChild(dateTag);

  const h3Tag = document.createElement("h3");
  h3Tag.innerText = article.title;
  articleTag.appendChild(h3Tag);

  articleContainer.appendChild(articleTag);
})