const itemsContainer = document.getElementById("js-items-container");

shopItems.forEach((item, i) => {
  const outer = document.createElement("section");
  outer.classList.add("item");
  outer.classList.add(`${themeColor}-main`);

  const imageOuter = document.createElement("div");  
  imageOuter.classList.add("imgOuter");

  if(radius) {
    if(typeof radius !== "string" 
      && typeof radius !== "undefined") {
        console.error("radius は文字列型になるはずです！ 問題文を見返してみましょう👀")
      }
    outer.style.borderRadius = radius;
    imageOuter.style.borderRadius = `${radius} ${radius} 0px 0px`;
  }

  outer.appendChild(imageOuter);
  
  const imageTag = document.createElement("img");
  imageTag.src = item.image;
  imageOuter.classList.add(`${themeColor}-sub`);
  imageOuter.appendChild(imageTag);

  const description = document.createElement("div");
  description.classList.add("item-description");
  
  const amountAndPriceTag = document.createElement("p"); 
  amountAndPriceTag.innerText = `${item.amount} ¥${item.price.toLocaleString()}`
  description.appendChild(amountAndPriceTag);

  const nameTag = document.createElement("h3");
  nameTag.innerText = item.name;
  description.appendChild(nameTag);

  const button = document.createElement("button");
  button.innerText = "カートに入れる";
  button.classList.add(`${themeColor}-button-light`);
  
  if(buttonCursor) button.style.cursor = buttonCursor;

  button.addEventListener("click", e => {
    const shoppingCart = JSON.parse(localStorage.getItem("shoppingCart"));

    const key = shopItems[i].name;

    if(shoppingCart[key]) ++shoppingCart[key];
    else shoppingCart[key] = 1;

    localStorage.setItem("shoppingCart", JSON.stringify(shoppingCart));
  });
  description.appendChild(button);
  
  outer.appendChild(description);

  itemsContainer.appendChild(outer);
})