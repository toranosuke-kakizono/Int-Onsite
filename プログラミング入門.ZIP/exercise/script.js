"use strict" // 👈 この行は消さないようにしましょう！










/*

ここから下はチームでのアクティビティに使います！

チームアクティビティの問題はこちらにあります: 
https://codechrysalis.notion.site/658e8f4f4cc14ee89b31799ea209b896?pvs=4

*/

// ショップのタイトルを変更しよう ⭐️

let title;



// 文章を編集しよう ⭐️

let welcomeText;



// テーマカラーを変更しよう ⭐️

let themeColor = "orange";



// 商品のタイトルを変更しよう ⭐️

let itemName1;
let itemName2;
let itemName3;
let itemName4;
let itemName5;



// 商品の個数と値段を変更しよう ⭐️

let itemAmount1;
let itemAmount2;
let itemAmount3;
let itemAmount4;
let itemAmount5;

let itemPrice1;
let itemPrice2;
let itemPrice3;
let itemPrice4;
let itemPrice5;



// お知らせの幅を変更しよう ⭐️

let newsWidthNum = 70;
let newsWidth;



// 商品一覧の枠やお知らせの角を丸くしよう ⭐️

let radiusNum = 30;
let radius = radiusNum + "px";



// カーソルの種類を変更しよう ⭐️⭐️

let buttonCursor;



// 商品の画像を配置しよう ⭐️⭐️

let itemImagePath1;
let itemImagePath2;
let itemImagePath3;
let itemImagePath4;
let itemImagePath5;



// 投稿したお知らせに今日の日付が入るようにしよう ⭐️⭐️⭐️

let today;


